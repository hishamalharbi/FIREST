import React from 'react';

function Dashboard() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>لوحة التحكم</h1>
      <p>مرحباً بك في منصة Watact!</p>
    </div>
  );
}

export default Dashboard;
